# DATA CLEANING & VISUALIZATION PROJECT
# Dataset: Student Performance

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load the raw dataset
df = pd.read_csv("student_performance_raw.csv")

print("RAW DATA")
print(df.head())
print("\nShape:", df.shape)
print("\nMissing values:")
print(df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())

# 2. Clean missing values
numeric_cols = df.select_dtypes(include=np.number).columns

for col in numeric_cols:
    df[col] = df[col].fillna(df[col].median())

# 3. Remove duplicate rows
df = df.drop_duplicates().reset_index(drop=True)

# 4. Detect and remove outliers using the IQR method
outlier_cols = ["Study_Hours", "Attendance", "Math_Score",
                "Physics_Score", "Computer_Score"]

for col in outlier_cols:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    df = df[(df[col] >= lower) & (df[col] <= upper)]

# 5. Final cleaned data
print("\nCLEANED DATA")
print(df.head())
print("\nFinal shape:", df.shape)
print("\nMissing values after cleaning:")
print(df.isnull().sum())
print("\nDuplicates after cleaning:", df.duplicated().sum())

# 6. Statistical summary
print("\nSTATISTICAL SUMMARY")
print(df.describe())

# 7. Visualization 1: Study Hours Distribution
plt.figure(figsize=(8, 5))
sns.histplot(df["Study_Hours"], kde=True)
plt.title("Distribution of Study Hours")
plt.xlabel("Study Hours")
plt.ylabel("Number of Students")
plt.tight_layout()
plt.show()

# 8. Visualization 2: Average subject scores
subject_cols = ["Math_Score", "Physics_Score", "Computer_Score"]
average_scores = df[subject_cols].mean()

plt.figure(figsize=(8, 5))
average_scores.plot(kind="bar")
plt.title("Average Scores by Subject")
plt.xlabel("Subject")
plt.ylabel("Average Score")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()

# 9. Visualization 3: Study Hours vs Math Score
plt.figure(figsize=(8, 5))
sns.scatterplot(data=df, x="Study_Hours", y="Math_Score")
plt.title("Study Hours vs Math Score")
plt.xlabel("Study Hours")
plt.ylabel("Math Score")
plt.tight_layout()
plt.show()

# 10. Visualization 4: Attendance vs Average Score
df["Average_Score"] = df[subject_cols].mean(axis=1)

plt.figure(figsize=(8, 5))
sns.scatterplot(data=df, x="Attendance", y="Average_Score")
plt.title("Attendance vs Average Score")
plt.xlabel("Attendance (%)")
plt.ylabel("Average Score")
plt.tight_layout()
plt.show()

# 11. Visualization 5: Correlation heatmap
plt.figure(figsize=(9, 6))
sns.heatmap(
    df[["Study_Hours", "Attendance", "Math_Score",
        "Physics_Score", "Computer_Score"]].corr(),
    annot=True,
    fmt=".2f"
)
plt.title("Correlation Between Numerical Variables")
plt.tight_layout()
plt.show()

# 12. Key findings
print("\nKEY FINDINGS")
print("1. Students with more study hours generally tend to have higher scores.")
print("2. Attendance has a positive relationship with overall performance.")
print("3. The dataset was cleaned by handling missing values and removing duplicates/outliers.")
print("4. The visualizations make the main patterns easier to understand.")

# 13. Save cleaned dataset
df.to_csv("student_performance_cleaned.csv", index=False)
print("\nCleaned dataset saved as student_performance_cleaned.csv")
